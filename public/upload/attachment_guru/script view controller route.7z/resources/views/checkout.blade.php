@extends('template.awal')
@section('judul')
Checkout
@endsection
@section('konten')
<!-- SECTION -->
<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
<!-- Order Details -->
<div class="col-md-5 ">
						<div class="section-title text-center">
							<h3 class="title">Your Order</h3>
						</div>
						<div class="order-summary">
							<div class="order-col">
								<div><strong>PRODUCT</strong></div>
								<div><strong>TOTAL</strong></div>
							</div>
							<div class="order-products">
                                @foreach(Cart::getContent() as $crt)
								<div class="order-col">
									<div>{{$crt->quantity}}x {{$crt->name}}</div>
									<div>${{$crt->price}}.00</div>
                                </div>
                                @endforeach
							</div>
							<div class="order-col">
								<div>Shipping</div>
								<div><strong>FREE</strong></div>
							</div>
							<div class="order-col">
								<div><strong>TOTAL</strong></div>
								<div><strong class="order-total">${{Cart::getTotal()}}.00</strong></div>
							</div>
						</div>
					
						<div class="input-checkbox">
							<input type="checkbox" id="terms" require>
							<label for="terms">
								<span></span>
								I've read and accept the <a href="#">terms & conditions</a>
							</label>
						</div>
                        <a href="{{url('clear')}}" class="primary-btn order-submit" style="background-color: gray; width: 100%;">Cancel all</a>
                        
                   
					</div>
					<!-- /Order Details -->
					<div class="col-md-7">
						<!-- Billing Details -->
						<div class="billing-details">
							<div class="section-title">
								<h3 class="title">Billing address</h3>
                            </div>
                        <form action="{{url('simpan')}}" method="POST">
                            @csrf
                            @foreach(Cart::getContent() as $crt)
                            <input class="input" type="hidden" name="nama_barang" value="{{$crt->name}}">
                            <input class="input" type="hidden" name="jumlah" value="{{$crt->quantity}}">
                            @endforeach
                            <input class="input" type="hidden" name="total_bayar" value="{{Cart::getTotal()}}">
							<div class="form-group">
								<input class="input" type="text" name="nama" placeholder="Your Name" value="{{Session('nama')}}">
							</div>
							<div class="form-group">
								<input class="input" type="email" name="email" placeholder="Email" value="{{Session('email')}}">
							</div>
							<div class="form-group">
								<input class="input" type="text" name="order_address" placeholder="Address">
							</div>
							<div class="form-group">
								<input class="input" type="text" name="city" placeholder="City">
							</div>
							<div class="form-group">
								<input class="input" type="text" name="country" placeholder="Country">
							</div>
							<div class="form-group">
								<input class="input" type="text" name="zip_code" placeholder="ZIP Code">
							</div>
							<div class="form-group">
								<input class="input" type="text" name="telephone" placeholder="Telephone">
							</div>
							<!-- <div class="form-group">
								<div class="input-checkbox">
									<input type="checkbox" id="create-account">
									<label for="create-account">
										<span></span>
										Create Account?
									</label>
									<div class="caption">
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>
										<input class="input" type="password" name="password" placeholder="Enter Your Password">
									</div>
								</div>
							</div> -->
						</div>
						<!-- /Billing Details -->

						

						<!-- Order notes -->
						<div class="order-notes">
							<textarea class="input" placeholder="Order Notes" name="order_notes"></textarea>
                        </div>
                        <div class="payment-method">
							<div class="input-radio">
								<input type="radio" name="payment" id="payment-1" value="Direct Bank Transfer">
								<label for="payment-1">
									<span></span>
									Direct Bank Transfer
								</label>
								<div class="caption">
									<p>Transfer your payment to this BRI account. Number : 719101001982507</p>
								</div>
							</div>
							<div class="input-radio">
								<input type="radio" name="payment" id="payment-3" value="OTS Payment">
								<label for="payment-3">
									<span></span>
									OTS Payment
								</label>
							</div>
						</div>
                   
						<!-- /Order notes -->
					</div>

					
                </div>
                <button type="submit" class="primary-btn order-submit" style="width: 100%;">Place order</button><br>
                </form>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->
@endsection

