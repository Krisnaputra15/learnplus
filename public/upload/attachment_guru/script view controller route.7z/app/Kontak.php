<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kontak extends Model
{
    protected $table="users";
    protected $primarykey="id";
    public $timestamps=false;
}
